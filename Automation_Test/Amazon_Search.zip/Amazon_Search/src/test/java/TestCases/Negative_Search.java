package TestCases;
import org.openqa.selenium.WebDriver;
import CommonFunctions.TestContext;
import Pages.LoginPage;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class Negative_Search {
	
	TestContext testContext;
	public WebDriver driver;
	public LoginPage loginpageinstance; 
	
	public Negative_Search(TestContext testContext) {
		this.testContext=testContext;
		driver = testContext.getDriver();
		loginpageinstance=testContext.getPageObjectManager().getLoginPage();
	}

	@When("^I search a specific keyword for Negative Case$")
	public void i_search_a_specific_keyword_for_Negative_Case() throws Throwable {
		loginpageinstance.negativeSearch();
	}

	@Then("^I close the Browser window$")
	public void i_close_the_Browser_window() throws Throwable {
		//loginpageinstance.closeBrowser();
	}

}
