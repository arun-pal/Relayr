package TestCases;
import org.openqa.selenium.WebDriver;
import CommonFunctions.TestContext;
import Pages.LoginPage;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class Positive_Search {
	
	TestContext testContext;
	public WebDriver driver;
	public LoginPage loginpageinstance; 
	
	public Positive_Search(TestContext testContext) {
		this.testContext=testContext;
		driver = testContext.getDriver();
		loginpageinstance=testContext.getPageObjectManager().getLoginPage();
	}

	@When("^I search a specific keyword with Positive Case$")
	public void i_search_a_specific_keyword_with_Positive_Case() throws Throwable {
		loginpageinstance.positiveSearch();

	}
	  
	@Then("^it gives the result and sort the data$")
	public void it_gives_the_result_and_sort_the_data() throws Throwable {
		loginpageinstance.sortItem();
	}

	@Then("^I close the Browser$")
	public void i_close_the_Browser() throws Throwable {
		loginpageinstance.closeBrowser();
	}
}
