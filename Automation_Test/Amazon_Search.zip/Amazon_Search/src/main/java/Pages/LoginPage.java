package Pages;
import java.io.IOException;
import java.util.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import CommonFunctions.Log;
import CommonFunctions.PropertyManager;
import CommonFunctions.SharedDriver;
public class LoginPage {

	private SharedDriver shareddriver;
	WebDriverWait wait;
	
	// All Locators related to the Login page is kept here. 
	private static String SEARCH_TEXTAREA_CLICK = "//input[@id='twotabsearchtextbox']";
	private static String SEARCH_BUTTON = "//input[@value='Go']";
	private static String POSITIVE_SEARCH_RESULT = "s-result-count";
	private static String SORT_BY_DROPDOWN = "sort";
	private static String PRICE_LOW_TO_HIGH = "//option[@value='price-asc-rank']";	
	private static String NEGATIVE_SEARCH_RESULT = "noResultsTitle";	
	
	public LoginPage(SharedDriver shareddriver) {
		this.shareddriver = shareddriver;
	}
	
	// Get the Search URL (Amazon Site)
	public void getURL() throws IOException{
		shareddriver.maximizeWindow();
		shareddriver.goToURL(PropertyManager.getProp("Url"));
	}
	
	// Search a Keyword or Item that's already Present.
	public void positiveSearch(){

		shareddriver.typeText(By.xpath(SEARCH_TEXTAREA_CLICK), PropertyManager.getProp("Positive_Search_Input"));
		shareddriver.click(By.xpath(SEARCH_BUTTON));
		String Search_Text = shareddriver.getText(By.id(POSITIVE_SEARCH_RESULT));
		System.out.println("Search Result is:" + PropertyManager.getProp("Positive_Search_Input") + "<=>" + Search_Text);		
	}
	
	// Search a Keyword or Item that's not Present.
	public void negativeSearch(){

		shareddriver.typeText(By.xpath(SEARCH_TEXTAREA_CLICK), PropertyManager.getProp("Negative_Search_Input"));
		shareddriver.click(By.xpath(SEARCH_BUTTON));
		String Search_Text = shareddriver.getText(By.id(NEGATIVE_SEARCH_RESULT));
		System.out.println("Search Result is:" + PropertyManager.getProp("Negative_Search_Input") + "<=>" + Search_Text);		
	}
	
	// Sort the result page based on Price Low to High.
	public void sortItem(){
		shareddriver.scrollToTopOfPage();
		shareddriver.waitForElementToBeClickable(By.id(SORT_BY_DROPDOWN));
		shareddriver.click(By.id(SORT_BY_DROPDOWN));
		shareddriver.click(By.xpath(PRICE_LOW_TO_HIGH));		
	}	
	
	// Closed the Browser.
	public void closeBrowser(){
		shareddriver.close();
	}
					
}